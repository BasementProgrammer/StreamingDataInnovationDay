output "passwword" {
  value = random_password.atp_admin.result
  sensitive = true
}

output "Incoming_Stream_ID" {
  value = module.incoming_stream.stream_id
}

output "streaming_endpoint" {
  value = module.incoming_stream.stream_endpoint
}
